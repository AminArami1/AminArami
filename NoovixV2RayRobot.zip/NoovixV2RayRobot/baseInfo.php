<?php
error_reporting(0);
$botToken = '7445080335:AAF-wdeOeuqdTsp-TyDRf3izb8sS5VFmT78'; // توکن ربات
$dbUserName = ''; // یوزرنیم دیتابیس
$dbPassword = ''; // پسورد دیتابیس
$dbName = ''; // نام دیتابیس
$botUrl = ''; // ادرس هاست و پوشه سورس
$admin =  '7892960313'; // آیدی عددی ادمین اصلی
?>
